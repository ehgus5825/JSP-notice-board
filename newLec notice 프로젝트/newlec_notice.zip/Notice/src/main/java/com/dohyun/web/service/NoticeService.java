package com.dohyun.web.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dohyun.web.dao.NoticeDAO;
import com.dohyun.web.entity.Notice;
import com.dohyun.web.entity.NoticeView;

public class NoticeService {
	NoticeDAO dao = new NoticeDAO();
	
/// -- notice/list ----------------------------------------------------------------------------------------------------------------------------------

	// ������ ���
	public List<NoticeView> getNoticeViewAdminList(){
		return getNoticeViewAdminList("title", "", 1);
	}
	
	public List<NoticeView> getNoticeViewAdminList(int page){
		return getNoticeViewAdminList("title", "", page);
	}
	
	public List<NoticeView> getNoticeViewAdminList(String field, String query, int page){
	    List<NoticeView> list = dao.selectAdminList(field, query, page);
	    return list;
	}
	
	// �⺻ ���
	public List<NoticeView> getNoticeViewList(){
		return getNoticeViewList("title", "", 1);
	}
	
	public List<NoticeView> getNoticeViewList(int page){
		return getNoticeViewList("title", "", page);
	}
	
	public List<NoticeView> getNoticeViewList(String field, String query, int page){
		List<NoticeView> list = dao.selectList(field, query, page);
	    return list;
	}
	
	// ������ �� ����
	public int getNoticeAdminCount() {
		return getNoticeAdminCount("title", "");
	}
	
	public int getNoticeAdminCount(String field, String query) {
		int count = dao.selectNoticeAdminCnt(field, query);
		return count;
	}

	// �� ����
	public int getNoticeCount() {
		return getNoticeCount("title", "");
	}
	
	public int getNoticeCount(String field, String query) {
		int count = dao.selectNoticeCnt(field, query);
		return count;
	}

	// �ϰ����� ��û 
	public int pubNoticeAll(int[] oids, int[] cids) {
		List<String> oidsList = new ArrayList<String>();
		for(int i =0; i < oids.length; i++)
			oidsList.add(String.valueOf(oids[i]));
		List<String> cidsList = new ArrayList<String>();
		for(int i =0; i < cids.length; i++)
			cidsList.add(String.valueOf(cids[i]));
		
		return pubNoticeAll(oidsList, cidsList);
	}
	
	public int pubNoticeAll(List<String> oids, List<String> cids) {
		String oidsCVS = String.join(",", oids);
		String cidsCVS = String.join(",", cids);
		
		return pubNoticeAll(oidsCVS, cidsCVS);
	}
	
	public int pubNoticeAll(String oidsCVS, String cidsCVS) {
		int result = dao.updatePubAll(oidsCVS, cidsCVS);
		return result;
	}
	
	// �ϰ����� ��û 
	public int removeNoticeAll(int[] dids) {
		List<String> didsList = new ArrayList<>();
		for(int i = 0; i < dids.length; i++)
			didsList.add(String.valueOf(dids[i]));
		
		return removeNoticeAll(didsList);
	}
	
	public int removeNoticeAll(List<String> didsList) {
		String dids_CVS = String.join(",", didsList);
		return removeNoticeAll(dids_CVS);
	}
	
	public int removeNoticeAll(String dids_CVS) {
		int result = dao.deleteNoticeAll(dids_CVS);
    	return result;
	}
		
/// -- notice/reg -----------------------------------------------------------------------------------------------------------------------------------

	// ������� ��û 
	public int regNotice(String title, String file, String writerId, String content, int open) {
		Notice notice = new Notice();
		notice.setTitle(title);
		notice.setFiles(file);
		notice.setWriterId(writerId);
		notice.setContent(content);
		notice.setPub(open);
		
		return regNotice(notice);
	}
	
	public int regNotice(Notice notice) {
		int result = dao.insertNotice(notice);
		return result;
	}
		
/// -- notice/detail --------------------------------------------------------------------------------------------------------------------------------
	
	// ����ȸ
	public Notice getNotice(int id) {
		Notice n = dao.selectNotice(id);
		return n;
	}
	
	// ������ ������ ����ȸ
	public Notice getNextAdminNotice(int id, String field, String query) {
		Notice n = dao.selectNextAdminNotice(id, field, query);
		return n;
	}

	// ������ ������ ����ȸ
	public Notice getPrevAdminNotice(int id, String field, String query) {
		Notice n = dao.selectPrevAdminNotice(id, field, query);
		return n;		
	}
	
	// ������ ����ȸ
	public Notice getNextNotice(int id, String field, String query) {
	    Notice n = dao.selectNextNotice(id, field, query);
		return n;		
	}

	// ������ ����ȸ
	public Notice getPrevNotice(int id, String field, String query) {
		Notice n = dao.selectPrevNotice(id, field, query);
	  	return n;
	}
	
/// -- notice/delete --------------------------------------------------------------------------------------------------------------------------------	

	// �������� ��û 
	public int removeNotice(int id) {
		int result = dao.deleteNotice(id);
    	return result;
	}
	
/// -- notice/update --------------------------------------------------------------------------------------------------------------------------------
	
	// �������� ��û 
	public int modifyNotice(int id, String title, String file, String content, int open) {
		Notice notice = new Notice();
		notice.setNid(id);
		notice.setTitle(title);
		notice.setFiles(file);
		notice.setContent(content);
		notice.setPub(open);
		
		return modifyNotice(notice);
	}
	
	public int modifyNotice(Notice notice) {
		int result = dao.updateNotice(notice);
    	return result;
	}
	
/// -- index ----------------------------------------------------------------------------------------------------------------------------------------

	// ������ ������ ��û 
	public List<Notice> getNoticeAdminNewestList(){
		List<Notice> list = dao.selectAdminNewestList();
  	    return list;
	}

	// ������ ��û 
	public List<Notice> getNoticeNewestList(){
		List<Notice> list = dao.selectNewestList();
		return list;
	}

/// -- member/myPage ----------------------------------------------------------------------------------------------------------------------------------------
	
	// �� �� ���
	public List<NoticeView> getMyNoticeViewList(){
		return getMyNoticeViewList("title", "", 1, "");
	}
	
	public List<NoticeView> getMyNoticeViewList(int page){
		return getMyNoticeViewList("title", "", page, "");
	}
	
	public List<NoticeView> getMyNoticeViewList(String field, String query, int page, String mid){		
	    List<NoticeView> list = dao.selectMyList(field, query, page, mid);
	    return list;
	}

	// �� �ۼ�
	public int getMyNoticeCount() {
		return getMyNoticeCount("title", "", "");
	}
	
	public int getMyNoticeCount(String field, String query, String mid) {
		int count = dao.selectMyNoticeCnt(field, query, mid);
		return count;				
	}

	// ���� �� �� ����ȸ
	public Notice getNextMyNotice(int id, String mid, String field, String query) {
		Notice n = dao.selectNextMyNotice(id, mid, field, query);
		return n;		
	}

	// ���� �� �� ����ȸ
	public Notice getPrevMyNotice(int id, String mid, String field, String query) {
		Notice n = dao.selectPrevMyNotice(id, mid, field, query);
		return n;
	}
}



