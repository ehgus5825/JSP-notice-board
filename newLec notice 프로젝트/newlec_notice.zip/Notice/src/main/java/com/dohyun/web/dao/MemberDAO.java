package com.dohyun.web.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dohyun.web.entity.Member;

public class MemberDAO {
	private static Connection con;
	private static PreparedStatement st;
	private static ResultSet rs;
	
	public static Connection getConnect() {
		String url = "jdbc:oracle:thin:@localhost:1521/xepdb1";
		String uid = "DOHYUN"; 
		String pwd = "ASD123";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, uid, pwd);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	public static void dbClose() {
		try {
			if(rs != null)
				rs.close();
			if(st != null)
				st.close();
			if(con != null)
				con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

// -- member/join->confirm ----------------------------------------------------------------------------------------------------------------------------------
	
	public int insertMember(Member member) {
		int result = 0;
		  
	    try {
			con = getConnect();
			String sql = "INSERT INTO member (id, pwd, name, gender, birthday, phone, emall ) VALUES (?,?,?,?,?,?,?)";
			st = con.prepareStatement(sql);
		    st.setString(1, member.getMid());
		    st.setString(2, member.getPwd());
		    st.setString(3, member.getName());
		    st.setString(4, member.getGender());
		    st.setString(5, member.getBirthday());
		    st.setString(6, member.getPhone());
		    st.setString(7, member.getEmail());
		    result = st.executeUpdate();
		   		   
		    dbClose();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
// -- member/join->dupl -------------------------------------------------------------------------------------------------------------------------------------	
	
	public int selectMemberCnt(String id) {
		int result = 0;
		
		try {
			con = getConnect();
			String sql = "SELECT COUNT(ID) CNT FROM MEMBER WHERE ID = ?";
			st = con.prepareStatement(sql);
			st.setString(1, id);
		    rs = st.executeQuery();
		    
		    if(rs.next()) {
		    	result = rs.getInt("CNT");
		    }

		    dbClose();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

// -- member/login ------------------------------------------------------------------------------------------------------------------------------------------

	public Member selectMember(String id) {
		Member member = null;
		
		try {
			con = getConnect();
			String sql = "SELECT * FROM MEMBER WHERE ID = ?";
			st = con.prepareStatement(sql);
			st.setString(1, id);
		    rs = st.executeQuery();
		    
		    if(rs.next()) {
		    	Member m = new Member();
		    	m.setMid(rs.getString("ID"));
		    	m.setPwd(rs.getString("PWD"));
		    	m.setName(rs.getString("NAME"));
		    	m.setGender(rs.getString("GENDER"));
		    	m.setBirthday(rs.getString("BIRTHDAY"));
		    	m.setPhone(rs.getString("PHONE"));
		    	m.setEmail(rs.getString("EMALL"));
		    	m.setRole(rs.getString("ROLE"));
		    	member = m;
		    }
		    
		    dbClose();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return member;
	}
	
}
