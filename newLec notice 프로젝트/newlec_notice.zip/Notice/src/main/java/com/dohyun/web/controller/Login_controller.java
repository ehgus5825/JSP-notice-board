package com.dohyun.web.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.dohyun.web.entity.Member;
import com.dohyun.web.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;

@WebServlet("/memberLogin")
public class Login_controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		HttpSession session = req.getSession();
		Member member = (Member)session.getAttribute("userMember");
		
		if(member != null) {
			writer.println("<script>alert('�̹� �α����� �Ǿ��ֽ��ϴ�.'); history.back();</script>");
		}
		else {
			req.getRequestDispatcher("WEB-INF/view/member/login.jsp").forward(req, resp);
		}
		writer.close();
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String mid = req.getParameter("username");
		String pwd = req.getParameter("password");
		
		PrintWriter writer = resp.getWriter();
		
		MemberService service = new MemberService();
		Member member = service.getMember(mid);
		
		if(member != null) {
			if(mid.equals(member.getMid()) && pwd.equals(member.getPwd())){
				HttpSession session = req.getSession();
				session.setAttribute("userMember", member);
				session.setMaxInactiveInterval(60*60);
				
				writer.println("<script>alert('�α����� �Ϸ�Ǿ����ϴ�.'); location.href='/index';</script>");
			}
			else {
				writer.println("<script>alert('���̵�� ��й�ȣ�� Ȯ�����ּ���.'); location.href='/memberLogin';</script>");
			}
		}
		else {
			writer.println("<script>alert('���̵�� ��й�ȣ�� Ȯ�����ּ���.'); location.href='/memberLogin';</script>");
		}
		writer.close();
	}
}
