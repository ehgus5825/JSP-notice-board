package com.dohyun.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dohyun.web.entity.NoticeView;
import com.dohyun.web.service.NoticeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/noticeList")
public class List_controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		// �Է�
		String page_ = req.getParameter("p");
		String field = req.getParameter("f");
		String query = req.getParameter("q");
		
		field = (field==null)?"title":(field=="")?"title":field;
		query = (query==null)?"":query;
		int page = (page_==null)?1:(page_=="")?1:Integer.parseInt(page_);
		
		// NoticeService ��ü ����
		NoticeService service = new NoticeService();
		
		// list �ޱ�
		List<NoticeView> list1 = service.getNoticeViewList(field, query, page);
		List<NoticeView> list2 = service.getNoticeViewAdminList(field, query, page);
		
		// �Խñ� ��ü ���� �ޱ�
		int count1 = service.getNoticeCount(field, query);
		int count2 = service.getNoticeAdminCount(field, query);
		
		// ���
		req.setAttribute("list1", list1);
		req.setAttribute("list2", list2);
		req.setAttribute("count1", count1);
		req.setAttribute("count2", count2);
		req.getRequestDispatcher("WEB-INF/view/notice/list.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// NoticeService ��ü ����
		NoticeService service = new NoticeService();
		
		String[] open_ids_ = req.getParameterValues("open_id");
		String[] del_ids_ = req.getParameterValues("del_id");
		String btn = req.getParameter("btn");
		String[] list_ids_ = req.getParameter("ids").trim().split(" ");		
		
		System.out.println("open");
		System.out.println(req.getParameter("ids"));
		
		System.out.println("open");
		if(open_ids_ != null)
			System.out.println(Arrays.asList(open_ids_));
		else
			System.out.println("[]");
		System.out.println("del");
		if(del_ids_ != null)
			System.out.println(Arrays.asList(del_ids_));
		else
			System.out.println("[]");
		System.out.println("list");
		System.out.println(Arrays.asList(list_ids_));
		
		if(btn.equals("�ϰ�����")) {
			List<String> oid;
			if(open_ids_ != null)
				oid = Arrays.asList(open_ids_);
			else
				oid = Arrays.asList();
			
			List<String> cid = new ArrayList<>(Arrays.asList(list_ids_));
			cid.removeAll(oid);
			
			int result = service.pubNoticeAll(oid, cid);
			
			System.out.println("�����Ͱ� " + result + "����ŭ �����Ǿ����ϴ�."); 
		}
		else if(btn.equals("�ϰ�����") && del_ids_ != null) {
			int[] del_ids = new int[del_ids_.length];
			for(int i = 0; i < del_ids_.length; i++)
				del_ids[i] = Integer.parseInt(del_ids_[i]);
			
			int result = service.removeNoticeAll(del_ids);
				
			System.out.println("�����Ͱ� " + result + "����ŭ �����Ǿ����ϴ�.");
			
		}
		
		resp.sendRedirect("noticeList");
	}
}
