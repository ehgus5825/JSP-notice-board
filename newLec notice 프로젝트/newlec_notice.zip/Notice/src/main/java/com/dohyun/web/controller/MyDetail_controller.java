package com.dohyun.web.controller;

import java.io.IOException;

import com.dohyun.web.entity.Member;
import com.dohyun.web.entity.Notice;
import com.dohyun.web.service.NoticeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/memberMyDetail")
public class MyDetail_controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// �Է�
		String nid_ = req.getParameter("id");
		int nid = (nid_==null)?1:(nid_=="")?1:Integer.parseInt(nid_);

		String field = req.getParameter("f");
		String query = req.getParameter("q");
		
		field = (field==null)?"title":(field=="")?"title":field;
		query = (query==null)?"":query;
		
		HttpSession session = req.getSession();
		Member member = (Member)session.getAttribute("userMember");
		
		// NoticeService ��ü ����
		NoticeService service = new NoticeService();
		
		// ��
		Notice notice = service.getNotice(nid);
		// ����
		Notice nextNotice = service.getNextMyNotice(nid, member.getMid(), field, query);
		// ����
		Notice prevNotice = service.getPrevMyNotice(nid, member.getMid(), field, query);
		
		// ���
		req.setAttribute("n", notice);
		req.setAttribute("nextN", nextNotice);
		req.setAttribute("pervN", prevNotice);		
		req.getRequestDispatcher("/WEB-INF/view/member/myDetail.jsp").forward(req, resp);
	}
}
