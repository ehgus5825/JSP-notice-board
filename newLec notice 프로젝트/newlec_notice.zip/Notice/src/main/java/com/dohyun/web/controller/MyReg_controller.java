package com.dohyun.web.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.dohyun.web.entity.Member;
import com.dohyun.web.entity.Notice;
import com.dohyun.web.service.NoticeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@MultipartConfig(
	fileSizeThreshold=1024*1024,
    maxFileSize=1024*1024*5,
    maxRequestSize=1024*1024*5*5
)
@WebServlet("/memberMyReg")
public class MyReg_controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("WEB-INF/view/member/myReg.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		Member member = (Member)session.getAttribute("userMember");
		
		String title = req.getParameter("title");
		Part filePart = req.getPart("file");
		String content = req.getParameter("content");
		String open_ = req.getParameter("open");
		
		String fileName = "";
		
		if(filePart != null && filePart.getName().equals("file") && filePart.getSize() != 0) {
		
			fileName = filePart.getSubmittedFileName();
			InputStream fis = filePart.getInputStream();
			
			String realPath = req.getServletContext().getRealPath("/upload");      
		
			File path = new File(realPath);
			if(!path.exists())
			    path.mkdir();
		
			String filePath = realPath + File.separator + fileName;
			FileOutputStream fos = new FileOutputStream(filePath);
			
			byte[] buf = new byte[1024];
			int size = 0;
			while((size=fis.read(buf)) != -1)
			    fos.write(buf, 0, size);
		
			fos.close();
			fis.close();
						
		}
		
		int open = 1;
		if(open_ == null) {
			open = 0;
		}
		
		Notice notice = new Notice();
		notice.setTitle(title);
		notice.setFiles(fileName);
		notice.setWriterId(member.getMid());
		notice.setContent(content);
		notice.setPub(open);
		
		NoticeService service = new NoticeService();
		int result = service.regNotice(notice);
		
		System.out.println("�����Ͱ� " + result + "����ŭ �߰��Ǿ����ϴ�."); 
		
		resp.sendRedirect("memberMyPage");
	}
}
