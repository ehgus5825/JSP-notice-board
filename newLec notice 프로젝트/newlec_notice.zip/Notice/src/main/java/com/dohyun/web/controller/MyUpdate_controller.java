package com.dohyun.web.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.dohyun.web.entity.Notice;
import com.dohyun.web.service.NoticeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig(
		fileSizeThreshold=1024*1024,
	    maxFileSize=1024*1024*5,
	    maxRequestSize=1024*1024*5*5
	)
@WebServlet("/memberMyUpdate")
public class MyUpdate_controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		
		NoticeService service = new NoticeService();
		Notice notice = service.getNotice(id);
		
		req.setAttribute("n", notice);
		req.getRequestDispatcher("WEB-INF/view/member/myUpdate.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String title = req.getParameter("title");
		Part filePart = req.getPart("file");
		String content = req.getParameter("content");
		String open_ = req.getParameter("open");
		
		String fileName = "";
		
		if(filePart != null && filePart.getName().equals("file") && filePart.getSize() != 0) {

			fileName = filePart.getSubmittedFileName();
			InputStream fis = filePart.getInputStream();
			
			String realPath = req.getServletContext().getRealPath("/upload");      
	
			File path = new File(realPath);
			if(!path.exists())
			    path.mkdir();
	
			String filePath = realPath + File.separator + fileName;  
			FileOutputStream fos = new FileOutputStream(filePath);  // ���ڷ� ���� ��� ����
	
			byte[] buf = new byte[1024];
			int size = 0;
			while((size=fis.read(buf)) != -1)
			    fos.write(buf, 0, size);
			
			fos.close();
			fis.close();
			
		}
		
		int open = 1;
		if(open_ == null) {
			open = 0;
		}
		
		Notice notice = new Notice();
		notice.setNid(id);
		notice.setTitle(title);
		notice.setFiles(fileName);
		notice.setContent(content);
		notice.setPub(open);
		
		NoticeService service = new NoticeService();
		int result = service.modifyNotice(notice);
		
		System.out.println("�����Ͱ� " + result + "����ŭ �����Ǿ����ϴ�."); 
		
		resp.sendRedirect("memberMyPage");
	}
}
